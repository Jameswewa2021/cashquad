<!DOCTYPE html>
<html>
<head>
	<title>
mpesa
	</title>
</head>
<body>
<div align="center">
	<form method="post" action="get.php">
		<table>
			<tr>
				<td>
					Input message:
				</td>
			</tr>
			<tr>
				<td>
					<textarea name="message" cols="50" rows="4">
						Enter message:
					</textarea>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>
					<Input type="submit" value="submit">
				</td>
			</tr>
		</table>
	</form>
</div>
</body>
</html>